#' @importFrom stats  quantile lm qnorm reshape
#' @importFrom np  npreg
#' @importFrom ggplot2  ggplot geom_line geom_ribbon facet_wrap aes ylab
#' @importFrom methods  is
NULL
#> NULL

